using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCont : MonoBehaviour
{
    //movement
    PlayerAction inputAction;
    Vector2 move;
    Vector2 rotate;
    private float walkSpeed = 5f;
    public Camera playerCamera;
    Vector3 cameraRot;

    //jump
    Rigidbody rb;
    private float disToGround;
    private bool isGrounded;

    //anime
    Animator playerAnimator;
    private bool isWalking = false;

    //shoot
    public GameObject bullet;
    public Transform projectilePos;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<RigidBody>();
        playerAnimator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
